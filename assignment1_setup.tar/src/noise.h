/*
 * noise.cc
 * Copyright (C) 2022 Morgan McColl <morgan.mccoll@alumni.griffithuni.edu.au>
 *
 * Distributed under terms of the MIT license.
 */

double addNoise(double value, double stdDeviation); 

